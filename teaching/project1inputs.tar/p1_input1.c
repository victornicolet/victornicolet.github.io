int input1_simple_loop()
{
  int n = 10;
  int i, sum = 0;
  for ( i = 1; i <= 10; i++ ) {
    sum += i;
  }

  return sum;
}
