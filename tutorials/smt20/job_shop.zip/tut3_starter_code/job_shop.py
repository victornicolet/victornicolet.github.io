#!/usr/env/bin/python3
from z3 import *
from itertools import combinations


def solve_job_shop(alljobs, optimize=False):
    # TODO Complete this function.
    print("Complete the solve_job_shop function!")
    return False


# ================================================================================
#  You do not need to modify anything below this line.
# ================================================================================


def well_formed_problem(jobs):
    if not isinstance(jobs, list):
        return False
    for job in jobs:
        if not isinstance(job, list) or job == []:
            return False
        for task in job:
            try:
                machine_no, duration = task
                if machine_no < 0:
                    print("Tasks should be assigned to machines no > 0.")
                    return False
                if duration <= 0:
                    print("Tasks should have a duration larger than 0.")
                    return False
                break
            except TypeError:
                print("Tasks should be pairs (machine_no >= 0, duration > 0)")
                return False

    return True


# Main entry point: the script reads the input file passed as argument.
if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python job_shop.py INPUT_FILE [o]")
        print("\tHint: test_input contains two valid input files.")
        print("\tAdd the o parameter to search for an optimal solution.")
        exit(1)

    _jobs = []
    with open(sys.argv[1], 'r') as input_grid:
        for line in input_grid.readlines():
            _jobs.append(eval(line))

    if well_formed_problem(_jobs):
        if len(sys.argv) == 3 and sys.argv[2] == 'o':
            solve_job_shop(_jobs, True)
        else:
            solve_job_shop(_jobs)
    else:
        print("Input file does not define a well formed problem.")
        exit(1)
